var app = angular.module('myApp', ['ngRoute', 'ngAnimate', 'toaster']);

app.config(['$routeProvider',
  function ($routeProvider) {
        $routeProvider.
        when('/login', {
            title: 'Login',
            templateUrl: 'partials/login.html',
            controller: 'authCtrl'
        })
            .when('/logout', {
                title: 'Logout',
                templateUrl: 'partials/login.html',
                controller: 'logoutCtrl'
            })
            .when('/signup', {
                title: 'Signup',
                templateUrl: 'partials/signup.html',
                controller: 'authCtrl'
            })
            .when('/dashboard', {
                title: 'dashboard',
                templateUrl: 'partials/dashboard.html',
                controller: 'authCtrl'
            })
	    .when('/perform', {
                title: 'Perform',
                 templateUrl: 'partials/dashboard4.html',
		 controller: 'authCtrl'
            })

	    .when('/brief', {
                title: 'brief',
                 templateUrl: 'partials/dashboard2.html',
		 controller: 'authCtrl'
            })

	    .when('/mandate', {
                title: 'mandate',
                templateUrl: 'partials/dashboard1.html',
 		controller: 'authCtrl'
            })	
 //expanding to asset class
           .when('/AssetClass/CC', {
                title: 'AssetClass',
                templateUrl: 'partials/AssetClass/CC.html',
                controller: 'authCtrl',
               
            })
              .when('/AssetClass/AIPF', {
                title: 'AssetClass',
                templateUrl: 'partials/AssetClass/AIPF.html',
                controller: 'authCtrl',
               
            })
           .when('/AssetClass/GEPF', {
                title: 'AssetClass',
                templateUrl: 'partials/AssetClass/GEPF.html',
                controller: 'authCtrl',
               
            })
	     .when('/AssetClass/CP', {
                title: 'AssetClass',
                templateUrl: 'partials/AssetClass/CP.html',
                controller: 'authCtrl',
               
            })
             .when('/AssetClass/Others', {
                title: 'AssetClass',
                templateUrl: 'partials/AssetClass/Others.html',
                controller: 'authCtrl',
               
            })
             .when('/AssetClass/UIF', {
                title: 'AssetClass',
                templateUrl: 'partials/AssetClass/UIF.html',
                controller: 'authCtrl',
               
            })
	     
           .when('/AssetClass/back', {
                title: 'dashboard',
                templateUrl: 'partials/dashboard.html',
                controller: 'authCtrl',
               
            })
	       .when('/AssetClass/more', {
                title: 'more',
                templateUrl: 'partials/AssetClass/moreAssets.html',
                controller: 'authCtrl',
               
            })
	 .when('/', {
                title: 'Login',
                templateUrl: 'partials/login.html',
                controller: 'authCtrl',
                role: '0'
            })
		
            .otherwise({
                redirectTo: '/login'
            });
  }])
    .run(function ($rootScope, $location, Data) {
        $rootScope.$on("$routeChangeStart", function (event, next, current) {
            $rootScope.authenticated = false;
            Data.get('session').then(function (results) {
                if (results.uid) {
                    $rootScope.authenticated = true;
                    $rootScope.uid = results.uid;
                    $rootScope.name = results.name;
                    $rootScope.email = results.email;
			  
			 var mydiv = document.getElementById('id01');
                   mydiv.style.display = 'block';

                } else {
                    var nextUrl = next.$$route.originalPath;
                    if (nextUrl == '/signup' || nextUrl == '/login') {

                    } else {
                        $location.path("/login");
                    }
                }
            });
        });
    });

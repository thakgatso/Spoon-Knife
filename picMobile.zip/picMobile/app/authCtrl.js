app.controller('authCtrl', function ($scope, $rootScope, $routeParams, $location, $http, Data) {
    //initially set those objects to null to avoid undefined error
    $scope.login = {};
    $scope.signup = {};
    $scope.doLogin = function (picUser) {
        Data.post('login', {
            customer: picUser
        }).then(function (results) {
            Data.toast(results);
            if (results.status == "success") {
                $location.path('dashboard');
               
            }
        });
    };
 var hst='72.16.1.131';
 var prj='picMobile';
 var json='api/json';
 var fl='.php';
 var htt='http://1';
   $scope.signup = {email:'',password:'',name:'',phone:'',department:''};
    $scope.signUp = function (customer) {
        Data.post('signUp', {
            customer: customer
        }).then(function (results) {
            Data.toast(results);
            if (results.status == "success") {
                $location.path('dashboard');
            }
        });
    };
//----------------------first dashboard-------expand----------
//bottom 10
                $http.get(htt+hst+'/'+prj+'/'+json+'/bottom10bondsdata'+fl)
                                .success(function(data) {
                                                $scope.bottom10Bonds = data;
                                })
//get companies by asset class
    
 		 $scope.getCompanies = function(SelectedClient,SelectedAsset,selectedDate){
			
			  $('#assetTable').hide();
      			  $('#cmpyTable').show(1000);
                          
   			 $http.get(htt+hst+'/'+prj+'/'+json+'/CompaniesPerClass'+fl+'?&client='+SelectedClient+'&assetClass='+SelectedAsset+'&dated='+selectedDate)
                                .success(function(data) {
                                                $scope.aum = data;
                                })

			};


//market brief
                $http.get(htt+hst+'/'+prj+'/'+json+'/brief'+fl)
                                .success(function(brief) {
                                                $scope.MarketBrief = brief;
                                })
                             
//clients
                $http.get(htt+hst+'/'+prj+'/'+json+'/totAUM'+fl)
                                .success(function(total) {
                                                $scope.picClients = total;
                                })
                               
//listed
                $http.get(htt+hst+'/'+prj+'/'+json+'/listeddata.php')
                                .success(function(data2) {
                                                $scope.listed = data2;
                                })
                               
//top 5 bonds
                $http.get(htt+hst+'/'+prj+'/'+json+'/top5bondsholdingexposuredata'+fl)
                                .success(function(data3) {
                                                $scope.top5bonds = data3;
                                })
                               
//Top 5 corporate bonds holding by exposure
                $http.get(htt+hst+'/'+prj+'/'+json+'/top5corporatebondsholdingsexposure'+fl)
                                .success(function(data4) {
                                                $scope.top5CorporateBondsHoldingsExposure = data4;
                                })
                               
//Top 10 Equities
                $http.get(htt+hst+'/'+prj+'/'+json+'/top10equitiesdata.php')
                                .success(function(data5) {
                                                $scope.top10equities = data5;
                                })
                               
 
//unlisted
                $http.get(htt+hst+'/'+prj+'/'+json+'/unlisteddata'+fl)
                                .success(function(data6) {
                                                $scope.Unlisted = data6;
                                })
                               
//--------second dashboard expand---------------------
//Key Sectoral exposure.
                $http.get(htt+hst+'/'+prj+'/'+json+'/keysectoralexposuredata'+fl)
                                .success(function(secdata) {
                                                $scope.keySectoralExposure = secdata;
                                })
                               
//pic------------exposure--------------gdp
                $http.get(htt+hst+'/'+prj+'/'+json+'/picexposuregdpdata'+fl)
                                .success(function(secdata1) {
                                                $scope.picExposureGDP = secdata1;
                                })
                               
//pic------------exposure--------------total--issuence
                $http.get(htt+hst+'/'+prj+'/'+json+'/picexposuretotalissuencedata'+fl)
                                .success(function(secdata2) {
                                                $scope.picExposureTotalIssuence = secdata2;
                                })
                               
//top10-performer--equities--data----------------
                $http.get(htt+hst+'/'+prj+'/'+json+'/top10Performerequitiesdata'+fl)
                                .success(function(secdata3) {
                                                $scope.top10BondsHoldingExposure = secdata3;
                                })
                               
               
//------------------------mandate-function----------------json

  //AI Mandate
 
                $http.get(htt+hst+'/'+prj+'/'+json+'/AI_Mand'+fl)
                                .success(function(dataM1) {
                                                $scope.AIMand = dataM1;
                                })
                               
    //CC Mandate
                $http.get(htt+hst+'/'+prj+'/'+json+'/CC_Mand'+fl)
                                .success(function(dataM2) {
                                                $scope.CC_Mand = dataM2;
                                })
                               
 
      //CP Mandate
                $http.get(htt+hst+'/'+prj+'/'+json+'/CP_Mand'+fl)
                                .success(function(dataM3) {
                                                $scope.CP_Mand = dataM3;
                                })
                               
  //GEPF mandate
                $http.get(htt+hst+'/'+prj+'/'+json+'/GEPF_Mand'+fl)
                                .success(function(dataM4) {
                                                $scope.GEPF_Mand = dataM4;
                                })
                               
//UIF mandate
                $http.get(htt+hst+'/'+prj+'/'+json+'/UIF_Mand'+fl)
                                .success(function(dataM5) {
                                                $scope.UIF_Mand = dataM5;
                                })

//clients
		 $http.get(htt+hst+'/'+prj+'/'+json+'/clientsdata'+fl)
                               .success(function(data1) {
                                                $scope.picClients = data1;

                                })

//portfolio performence
		 $http.get(htt+hst+'/'+prj+'/'+json+'/prtfolioPerfdata'+fl)
                               .success(function(portfolio) {
                                                $scope.portfolioperformence = portfolio;

                             })
    
    $scope.logout = function () {
        Data.get('logout').then(function (results) {
            Data.toast(results);
            $location.path('login');
        });
  
 
    }
});

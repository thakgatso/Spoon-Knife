var app =angular.module('picApp', ['ionic','chart.js'])

app.config(function($stateProvider, $urlRouterProvider) {

  $stateProvider
    .state('signin', {
      url: '/sign-in',
      templateUrl: 'templates/sign-in.html',
      controller: 'SignInCtrl'
    })

    .state('tabs', {
      url: '/tab',
      abstract: true,
      templateUrl: 'templates/tabs.html'
    })
    .state('tabs.home', {
      url: '/home',
      views: {
        'home-tab': {
          templateUrl: 'templates/home.html',
          controller: 'HomeTabCtrl'
        }
      }
    })
     .state('tabs.Investment', {
	 url: '/Investment',
      views: {
        'home-tab': {
          templateUrl: 'templates/InvestmentHome.html',
        }
      }
    })
     .state('tabs.Research', {
	 url: '/Research',
      views: {
        'home-tab': {
          templateUrl: 'templates/ResearchHome.html',
        }
      }
    })
    .state('tabs.dashboard', {
      url: '/dashboard',
      views: {
        'home-tab': {
          templateUrl: 'templates/dashboard.html'
        }
      }
    })
    .state('tabs.about', {
      url: '/about',
      views: {
        'about-tab': {
          templateUrl: 'templates/about.html'
        }
      }
    })
    .state('tabs.navstack', {
      url: '/navstack',
      views: {
        'about-tab': {
          templateUrl: 'templates/nav-stack.html'
        }
      }
    })
     .state('tabs.market', {
      url: '/market',
      views: {
        'home-tab': {
          templateUrl: 'templates/market.html'
        }
      }
    })
	.state('tabs.chart', {
      url: '/chart',
      views: {
        'home-tab': {
          templateUrl: 'templates/chart.html'
        }
      }
    })
     .state('tabs.performence', {
      url: '/performence',
      views: {
        'home-tab': {
          templateUrl: 'templates/performence.html'
        }
      }
    })
      .state('tabs.mandate', {
      url: '/mandate',
      views: {
        'home-tab': {
          templateUrl: 'templates/mandate.html'
        }
      }
    })


//2nd drill................


  .state('tabs.CC', {
      url: '/CC',
      views: {
        'home-tab': {
          templateUrl: 'templates/CC.html'
        }
      }
    })
  .state('tabs.AIPF', {
      url: '/AIPF',
      views: {
        'home-tab': {
          templateUrl: 'templates/AIPF.html'
        }
      }
    })
	.state('tabs.CP', {
      url: '/CP',
      views: {
        'home-tab': {
          templateUrl: 'templates/CP.html'
        }
      }
    })
     .state('tabs.GEPF', {
      url: '/GEPF',
      views: {
        'home-tab': {
          templateUrl: 'templates/GEPF.html'
        }
      }
    })
      .state('tabs.UIF', {
      url: '/UIF',
      views: {
        'home-tab': {
          templateUrl: 'templates/UIF.html'
        }
      }
    })
  .state('tabs.moreAssets', {
      url: '/moreAssets',
      views: {
        'home-tab': {
          templateUrl: 'templates/moreAssets.html'
        }
      }
    })
        .state('tabs.Others', {
      url: '/Others',
      views: {
        'home-tab': {
          templateUrl: 'templates/dashboard.html'
        }
      }
    })
  .state('tabs.Total', {
      url: '/Total',
      views: {
        'home-tab': {
          templateUrl: 'templates/dashboard.htmll'
        }
      }
    })
    .state('tabs.contact', {
      url: '/contact',
      views: {
        'contact-tab': {
          templateUrl: 'templates/contact.html'
        }
      }
    });


   $urlRouterProvider.otherwise('/sign-in');

});

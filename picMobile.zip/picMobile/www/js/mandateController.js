
app.controller('mandateTabCtrl', function($scope,$http,$ionicActionSheet) {
	
	 var hst='ptatstvmob01';
 var prj='picMobileAPI';
 var json='api/json';
 var fl='.php';
 var htt='http://';


//listed
                $http.get('http://ptatstvmob01/picMobileapi/api/json/listeddata.php')
                                .success(function(listedInfo) {
                                                $scope.listed = listedInfo;
					
                                })
//unlisted
                $http.get(htt+hst+'/'+prj+'/'+json+'/unlisteddata'+fl)
                                .success(function(data6) {
                                                $scope.Unlisted = data6;
                                })

//top 5 bonds
                $http.get(htt+hst+'/'+prj+'/'+json+'/top5bondsholdingexposuredata'+fl)
                                .success(function(data3) {
                                                $scope.top5bonds = data3;
                                })
                               
//Top 5 corporate bonds holding by exposure
                $http.get(htt+hst+'/'+prj+'/'+json+'/top5corporatebondsholdingsexposure'+fl)
                                .success(function(data4) {
                                                $scope.top5CorporateBondsHoldingsExposure = data4;
                                })
//bottom 10 bonds
                $http.get(htt+hst+'/'+prj+'/'+json+'/bottom10bondsdata'+fl)
                                .success(function(bond) {
                                                $scope.bottom10bonds = bond;
                                })
                               
//Top 10 Equities
                $http.get(htt+hst+'/'+prj+'/'+json+'/top10equitiesdata.php')
                                .success(function(data5) {
                                                $scope.top10equities = data5;
                                })
                               
 

 /*                              
//--------second dashboard expand---------------------
//Key Sectoral exposure.
                $http.get(htt+hst+'/'+prj+'/'+json+'/keysectoralexposuredata'+fl)
                                .success(function(secdata) {
                                                $scope.keySectoralExposure = secdata;
                                })
                               
//pic------------exposure--------------gdp
                $http.get(htt+hst+'/'+prj+'/'+json+'/picexposuregdpdata'+fl)
                                .success(function(picexp) {
                                                $scope.picExposureGDP = picexp;
                                })
                               
//pic------------exposure--------------total--issuence
                $http.get(htt+hst+'/'+prj+'/'+json+'/picexposuretotalissuencedata'+fl)
                                .success(function(secdata2) {
                                                $scope.picExposureTotalIssuence = secdata2;
                                })
                               
//top10-performer--equities--data----------------
                $http.get(htt+hst+'/'+prj+'/'+json+'/top10Performerequitiesdata'+fl)
                                .success(function(secdata3) {
                                                $scope.top10BondsHoldingExposure = secdata3;
                                })

*/






//AI Mandate
 
                $http.get(htt+hst+'/'+prj+'/'+json+'/AI_Mand'+fl)
                                .success(function(dataM1) {
                                                $scope.AIMand = dataM1;
                                })
                               
//CC Mandate
                $http.get(htt+hst+'/'+prj+'/'+json+'/CC_Mand'+fl)
                                .success(function(ccmand) {
                                                $scope.CC_Mand = ccmand;
                                })
                               
 
//CP Mandate
                $http.get(htt+hst+'/'+prj+'/'+json+'/CP_Mand'+fl)
                                .success(function(cpmand) {
                                                $scope.CP_Mand = cpmand;
                                })
                               
//GEPF mandate
                $http.get(htt+hst+'/'+prj+'/'+json+'/GEPF_Mand'+fl)
                                .success(function(dataM4) {
                                                $scope.GEPF_Mand = dataM4;
                                })
                               
//UIF mandate
                $http.get(htt+hst+'/'+prj+'/'+json+'/UIF_Mand'+fl)
                                .success(function(uifmand) {
                                                $scope.UIF_Mand = uifmand;
                                })
//companies
 		$scope.getCompanies = function(SelectedClient,SelectedAsset,selectedDate){

   			 $http.get(htt+hst+'/'+prj+'/'+json+'/CompaniesPerClass'+fl+'?&client='+SelectedClient+'&assetClass='+SelectedAsset+'&dated='+selectedDate)
                                .success(function(data) {
                                                $scope.aum = data;
                                })



			};

})

app.controller('assetsTabCtrl', function($scope,$http) {
	
	 var hst='ptatstvmob01';
 var prj='picMobileAPI';
 var json='api/json';
 var fl='.php';
 var htt='http://';

//listed
                $http.get(htt+hst+'/'+prj+'/'+json+'/listeddata.php')
                                .success(function(data2) {
                                                $scope.listed = data2;
                                })
                               
//top 5 bonds
                $http.get(htt+hst+'/'+prj+'/'+json+'/top5bondsholdingexposuredata'+fl)
                                .success(function(data3) {
                                                $scope.top5bonds = data3;
                                })
                               
//Top 5 corporate bonds holding by exposure
                $http.get(htt+hst+'/'+prj+'/'+json+'/top5corporatebondsholdingsexposure'+fl)
                                .success(function(data4) {
                                                $scope.top5CorporateBondsHoldingsExposure = data4;
                                })
                               
//Top 10 Equities
                $http.get(htt+hst+'/'+prj+'/'+json+'/top10equitiesdata.php')
                                .success(function(data5) {
                                                $scope.top10equities = data5;
                                })
                               
 
//unlisted
                $http.get(htt+hst+'/'+prj+'/'+json+'/unlisteddata'+fl)
                                .success(function(data6) {
                                                $scope.Unlisted = data6;
                                })
                               
//--------second dashboard expand---------------------
//Key Sectoral exposure.
                $http.get(htt+hst+'/'+prj+'/'+json+'/keysectoralexposuredata'+fl)
                                .success(function(secdata) {
                                                $scope.keySectoralExposure = secdata;
                                })
                               
//pic------------exposure--------------gdp
                $http.get(htt+hst+'/'+prj+'/'+json+'/picexposuregdpdata'+fl)
                                .success(function(secdata1) {
                                                $scope.picExposureGDP = secdata1;
                                })
                               
//pic------------exposure--------------total--issuence
                $http.get(htt+hst+'/'+prj+'/'+json+'/picexposuretotalissuencedata'+fl)
                                .success(function(secdata2) {
                                                $scope.picExposureTotalIssuence = secdata2;
                                })
                               
//top10-performer--equities--data----------------
                $http.get(htt+hst+'/'+prj+'/'+json+'/top10Performerequitiesdata'+fl)
                                .success(function(secdata3) {
                                                $scope.top10BondsHoldingExposure = secdata3;
                                })
                               
               


			};

})